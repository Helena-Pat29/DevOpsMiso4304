class Config(object):
    SQLALCHEMY_DATABASE_URI = "postgresql://postgres:postgres@blacklistdb.c3belohbakcu.us-east-2.rds.amazonaws.com/blacklistdb"